# Jacana Prospect OS v2.0 — ABI + CRM

Single-page application para un usuario. Incluye Grupos ABI, OCR y publicaciones, aprendizaje (informes versionados, hipótesis y experimentos), CRM, exportación CSV y respaldo JSON.

## Instalación
Publicar `index.html` en la raíz del repositorio mediante GitHub Pages. No requiere backend; usa localStorage del mismo navegador. Abre la URL servida por HTTPS.

## Seguridad y límites
- La base de datos es local; no es segura para compartir dispositivos ni está sincronizada con otros usuarios. No subir respaldo con contactos al repositorio público.
- No hay acceso automatizado a Facebook. La búsqueda enlaza a Facebook; las publicaciones se incorporan manualmente o mediante OCR de capturas legítimamente obtenidas.
- El OCR utiliza Tesseract.js 5 por CDN; la red y descarga de modelos de reconocimiento son necesarios. Este componente debe probarse en el sitio publicado y con imágenes reales.
- El análisis ABI usa reglas de lenguaje y conteos, no IA generativa ni clasificación fiable de edad/nacionalidad. La interpretación se limita a evidencia agregada.
- Se necesitan consentimiento y finalidades válidas para tratar datos personales y contactar personas.

## Pruebas
`node --check app.js`
`python test.py` (Playwright instalado; pruebas de flujo en navegador con almacenamiento simulado, sin descarga externa de Tesseract).

## Datos / Migración
Primera apertura sin `jacana_prospect_integral_v2` importa las fichas del antiguo `jacana_prospect_os_v1` si existen en el mismo origen/navegador. Antes de cualquier migración real, exportar respaldo y comprobar registros.

## Publicación
Esta entrega es un paquete de implementación local. Un commit y pruebas sobre el GitHub Pages público deben verificarse por separado; no hay despliegue automático implicado por la descarga del archivo.
